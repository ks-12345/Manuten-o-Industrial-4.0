#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

#define ONE_WIRE_BUS 4
#define VIBRATION_PIN 18
#define CURRENT_PIN 34

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* serverName = "https://webhook.site/SEU_SITE";

unsigned long tempoLigado = 0;
unsigned long inicioLigado = 0;
bool maquinaLigada = false;

void setup() {
  Serial.begin(115200);
  pinMode(VIBRATION_PIN, INPUT_PULLUP);
  sensors.begin();

  WiFi.begin(ssid, password);
  Serial.print("Conectando ao WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Conectado!");
}

void loop() {

  sensors.requestTemperatures();
  float temperatura = sensors.getTempCByIndex(0);

  bool vibrando = !digitalRead(VIBRATION_PIN);

  int leituraCorrente = analogRead(CURRENT_PIN);
  float corrente = leituraCorrente * (3.3 / 4095.0);

  if (corrente > 1.0) {
    if (!maquinaLigada) {
      maquinaLigada = true;
      inicioLigado = millis();
    }
  } else {
    if (maquinaLigada) {
      maquinaLigada = false;
      tempoLigado += millis() - inicioLigado;
    }
  }

  String status = maquinaLigada ? "LIGADA" : "DESLIGADA";
if (WiFi.status() == WL_CONNECTED) {

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;
  http.begin(client, serverName);
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");

  String httpRequestData = "temperatura=" + String(temperatura) +
                           "&vibracao=" + String(vibrando ? 1 : 0) +
                           "&corrente=" + String(corrente) +
                           "&status=" + status +
                           "&tempo=" + String(tempoLigado / 1000);

  int httpResponseCode = http.POST(httpRequestData);

  Serial.print("Código HTTP: ");
  Serial.println(httpResponseCode);

  http.end();
}

  delay(5000);
}